# ResumeAI

AI-powered ATS-conscious resume builder with 19 templates, resume editing, keyword overlap analysis, account registration/login, MongoDB resume storage, and PDF printing.

## Features
- 19 selectable templates: Corporate Elite, Minimal Classic, Elegant Edge, Nova CV, Prime Resume, Zenith, Aura CV, Fresh Start, Career Launch, FirstStep, Tech Talent, Executive Pro, Skyline, Vision CV, Prestige, NextGen, Impact, Elevate, Apex Resume.
- Job description based AI resume rewriting using Gemini.
- Candidate profile editor for summary, skills, experience, education, projects, certifications and achievements.
- ATS keyword overlap estimator (not an employer ATS score).
- JWT authentication with bcrypt password hashing.
- Save resumes to MongoDB.
- Print / Save as PDF using browser print.

## Run locally
1. Install Node.js 18.17+.
2. Copy `.env.example` to `.env.local`.
3. Set `MONGODB_URI`, `JWT_SECRET`, and `GEMINI_API_KEY`.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open http://localhost:3000.

AI generation requires a valid Gemini API key. Never put API keys in frontend code or commit `.env.local`.

## GitHub deployment
1. Create a GitHub repository named `resumeai`.
2. Upload this project (do not upload `.env.local` or `node_modules`).
3. Create a MongoDB Atlas database and allow network access for your deployment host.
4. Deploy the repository on Vercel as a Next.js app.
5. Add `MONGODB_URI`, `JWT_SECRET`, `GEMINI_API_KEY`, and `NEXT_PUBLIC_APP_URL` in Vercel Project Settings → Environment Variables.
6. Redeploy.

## API routes
- `POST /api/auth/register` — `{name,email,password}`
- `POST /api/auth/login` — `{email,password}`
- `POST /api/ai/generate` — `{jobDescription,resume}`; optional Bearer token
- `GET /api/resumes` — requires `Authorization: Bearer <token>`
- `POST /api/resumes` — requires `Authorization: Bearer <token>`

## Production hardening before public launch
Add rate limiting and abuse protection to AI generation; email verification and password reset; CSRF/origin protections as appropriate; stricter schema validation; resume ownership-scoped update/delete endpoints; automated tests; privacy policy and data deletion controls. Review AI output for factual accuracy before sending applications.

## Important ATS note
Templates use selectable visual accents but share a simple, text-first structure. No template or score can guarantee passing every ATS. For maximum compatibility use a single-column layout, conventional headings, readable fonts, and avoid tables, icons, text boxes and graphics in the final resume.
