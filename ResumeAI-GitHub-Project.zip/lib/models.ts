import mongoose, {Schema} from "mongoose";
const UserSchema = new Schema({name:{type:String,required:true},email:{type:String,required:true,unique:true},passwordHash:{type:String,required:true}},{timestamps:true});
const ResumeSchema = new Schema({
  userId:{type:Schema.Types.ObjectId,ref:"User",required:true,index:true},
  title:{type:String,default:"My Resume"},templateId:{type:String,default:"minimal-classic"},
  jobDescription:{type:String,default:""},
  content:{type:Schema.Types.Mixed,required:true}
},{timestamps:true});
export const User = mongoose.models.User || mongoose.model("User",UserSchema);
export const Resume = mongoose.models.Resume || mongoose.model("Resume",ResumeSchema);
