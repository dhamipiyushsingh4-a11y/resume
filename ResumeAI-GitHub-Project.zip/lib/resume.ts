export type ResumeContent = {
  fullName:string; email:string; phone:string; location:string; linkedin:string; github:string;
  summary:string; skills:string[]; experience:{role:string;company:string;dates:string;bullets:string[]}[];
  education:{degree:string;school:string;dates:string;details:string}[];
  projects:{name:string;description:string;technologies:string[]}[];
  certifications:string[]; achievements:string[];
};
export const emptyResume:ResumeContent = {
 fullName:"Your Name",email:"you@example.com",phone:"",location:"",linkedin:"",github:"",
 summary:"Write a concise professional summary tailored to your target role.",
 skills:[],experience:[],education:[],projects:[],certifications:[],achievements:[]
};
