import jwt from "jsonwebtoken";
export function signToken(user:any){return jwt.sign({userId:String(user._id),email:user.email},process.env.JWT_SECRET!,{expiresIn:"7d"});}
export function readToken(token:string){return jwt.verify(token,process.env.JWT_SECRET!) as {userId:string,email:string};}
