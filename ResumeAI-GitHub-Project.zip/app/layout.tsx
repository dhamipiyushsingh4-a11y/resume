import "./globals.css";
export const metadata={title:"ResumeAI — AI Resume Builder",description:"Create job-tailored, ATS-conscious resumes with AI."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
